import { useRef, useState, useCallback } from "react";
import { motion } from "motion/react";

const PROJECTS = [
  {
    id: 1,
    number: "01",
    tag: "E-Commerce · Front-end Dev",
    title: "MomMilk Platform",
    description:
      "E-commerce platform for baby and mom milk products. Allows users to browse and purchase infant formula, toddler milk, and nutrition supplements for mothers.",
    tech: ["ASP.NET Core", "Node.js", "Firebase", "MySQL", "Sandbox"],
    hue: 160,
    teamSize: 4,
    githubUrl: "https://github.com/devbaoo/Mommilk",
    color: "#39ff14",
  },
  {
    id: 2,
    number: "02",
    tag: "Mobile · Full-stack Dev",
    title: "MÔME Food Order",
    description:
      "Food ordering app for Vinhomes District 9 residents with baby health tracking: weight, height, feeding schedules, vaccination records and growth progress.",
    tech: ["Android Studio", "SQLite", "TogetherAI API", "PayOS"],
    hue: 330,
    teamSize: 2,
    liveUrl: "https://apkpure.com/mômê/com.dk.foodorder",
    color: "#ff2d78",
  },
  {
    id: 3,
    number: "03",
    tag: "SaaS · Front-end + Mobile",
    title: "Orchid Research & Lab",
    description:
      "Digital platform modernising botanical research via cloud-based management and AI-driven predictive analytics. Uses YOLOv8 to monitor and forecast orchid growth patterns.",
    tech: ["ReactJS", "React Native", "Tailwind CSS", "ASP.NET Core", "YOLOv8", "PostgreSQL"],
    hue: 200,
    teamSize: 4,
    githubUrl: "https://github.com/orchid-lab",
    color: "#00cfff",
  },
];

const ProjectCard = ({ p, index }: { p: typeof PROJECTS[0]; index: number }) => {
  const cardRef = useRef<HTMLDivElement>(null);
  const [tilt, setTilt] = useState({ x: 0, y: 0 });
  const [hov, setHov] = useState(false);

  const onMove = useCallback((e: React.MouseEvent<HTMLDivElement>) => {
    const r = cardRef.current!.getBoundingClientRect();
    const dx = (e.clientX - r.left - r.width / 2) / (r.width / 2);
    const dy = (e.clientY - r.top - r.height / 2) / (r.height / 2);
    setTilt({ x: -dy * 7, y: dx * 7 });
  }, []);

  return (
    <motion.div
      initial={{ opacity: 0, y: 50 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, amount: .15 }}
      transition={{ duration: .7, delay: index * .15, ease: [.16,1,.3,1] }}
      style={{ perspective: 1200 }}
    >
      <motion.div
        ref={cardRef}
        className="proj-card"
        onMouseMove={onMove}
        onMouseEnter={() => setHov(true)}
        onMouseLeave={() => { setTilt({ x:0, y:0 }); setHov(false); }}
        animate={{ rotateX: tilt.x, rotateY: tilt.y, y: hov ? -10 : 0 }}
        transition={{ type: "spring", stiffness: 180, damping: 18 }}
      >
        {/* Top bar */}
        <div style={{
          height: 200,
          background: `linear-gradient(135deg, #0a0a0a, hsl(${p.hue},20%,8%))`,
          position: "relative",
          overflow: "hidden",
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
        }}>
          {/* Grid pattern */}
          <svg style={{ position:"absolute",inset:0,width:"100%",height:"100%",opacity:.12 }}>
            <defs>
              <pattern id={`g${p.id}`} width="24" height="24" patternUnits="userSpaceOnUse">
                <path d="M 24 0 L 0 0 0 24" fill="none" stroke={p.color} strokeWidth=".5"/>
              </pattern>
            </defs>
            <rect width="100%" height="100%" fill={`url(#g${p.id})`}/>
          </svg>

          {/* Number watermark */}
          <span style={{
            fontFamily: "var(--font-display)",
            fontSize: "8rem",
            color: `${p.color}10`,
            userSelect: "none",
            lineHeight: 1,
          }}>{p.number}</span>

          {/* Glow orb */}
          <div style={{
            position:"absolute",
            width:160, height:160,
            borderRadius:"50%",
            background: `radial-gradient(circle, ${p.color}22 0%, transparent 70%)`,
            top:"10%", right:"10%",
            transition: "opacity .4s",
            opacity: hov ? 1 : .4,
          }}/>

          {/* Bottom line */}
          <div style={{
            position:"absolute", bottom:0, left:0, right:0,
            height:1,
            background: `linear-gradient(90deg, ${p.color}, transparent)`,
            opacity: hov ? 1 : .25,
            transition: "opacity .4s",
          }}/>

          {/* Team badge */}
          <div style={{
            position:"absolute", top:12, right:12,
            fontFamily:"var(--font-mono)", fontSize:".6rem",
            color: p.color, border:`0.5px solid ${p.color}44`,
            padding:".2rem .5rem", borderRadius:3,
          }}>
            Team {p.teamSize}
          </div>
        </div>

        {/* Body */}
        <div style={{ padding:"1.5rem" }}>
          <div style={{ fontFamily:"var(--font-mono)", fontSize:".62rem", color: p.color, letterSpacing:".12em", textTransform:"uppercase", marginBottom:".4rem" }}>{p.tag}</div>

          <h3 style={{ fontFamily:"var(--font-display)", fontSize:"1.6rem", letterSpacing:".04em", marginBottom:".6rem", color:"var(--text)" }}>{p.title}</h3>

          <p style={{ fontSize:".82rem", color:"#666", lineHeight:1.75, fontWeight:300, marginBottom:"1.25rem" }}>{p.description}</p>

          <div style={{ display:"flex", gap:".35rem", flexWrap:"wrap", marginBottom:"1.25rem" }}>
            {p.tech.map(t => (
              <span key={t} style={{
                padding:".18rem .55rem",
                background:`${p.color}0d`,
                border:`0.5px solid ${p.color}33`,
                borderRadius:3,
                fontFamily:"var(--font-mono)", fontSize:".6rem", color: p.color,
              }}>{t}</span>
            ))}
          </div>

          <div style={{ display:"flex", gap:"1rem" }}>
            {p.githubUrl && (
              <a href={p.githubUrl} target="_blank" rel="noopener noreferrer" style={{
                fontFamily:"var(--font-mono)", fontSize:".7rem", color:"var(--muted)",
                textDecoration:"none", letterSpacing:".06em", transition:"color .3s",
              }}
                onMouseEnter={e => (e.currentTarget.style.color = p.color)}
                onMouseLeave={e => (e.currentTarget.style.color = "var(--muted)")}
              >GitHub ↗</a>
            )}
            {p.liveUrl && (
              <a href={p.liveUrl} target="_blank" rel="noopener noreferrer" style={{
                fontFamily:"var(--font-mono)", fontSize:".7rem", color:"var(--muted)",
                textDecoration:"none", letterSpacing:".06em", transition:"color .3s",
              }}
                onMouseEnter={e => (e.currentTarget.style.color = p.color)}
                onMouseLeave={e => (e.currentTarget.style.color = "var(--muted)")}
              >Live ↗</a>
            )}
          </div>
        </div>
      </motion.div>
    </motion.div>
  );
};

const ProjectsSection = () => (
  <section id="projects" style={{ background:"var(--bg2)", padding:"8rem 2rem", minHeight:"100vh" }}>
    <div style={{ maxWidth:1080, margin:"0 auto" }}>

      <motion.div
        initial={{ opacity:0, y:30 }}
        whileInView={{ opacity:1, y:0 }}
        viewport={{ once:true }}
        style={{ marginBottom:"5rem" }}
      >
        <p className="section-label">03 / Work</p>
        <h2 style={{ fontFamily:"var(--font-display)", fontSize:"clamp(2.5rem,7vw,5rem)", lineHeight:.95 }}>
          SELECTED <span className="neon-green">PROJECTS</span>
        </h2>
      </motion.div>

      <div style={{ display:"grid", gridTemplateColumns:"repeat(auto-fit, minmax(300px,1fr))", gap:"1.5rem" }}>
        {PROJECTS.map((p, i) => <ProjectCard key={p.id} p={p} index={i} />)}
      </div>
    </div>
  </section>
);

export default ProjectsSection;
