import { useBackgroundMusic } from "../../hooks/useBackgroundMusic";
import { bootAudio } from "../../hooks/useSound";

const Bars = ({ active }: { active: boolean }) => (
  <svg width="22" height="22" viewBox="0 0 22 22" fill="none">
    {active && (
      <style>{`
        @keyframes b1{0%,100%{transform:scaleY(.3)}50%{transform:scaleY(1.1)}}
        @keyframes b2{0%,100%{transform:scaleY(.8)}50%{transform:scaleY(.2)}}
        @keyframes b3{0%,100%{transform:scaleY(.5)}50%{transform:scaleY(1.3)}}
        @keyframes b4{0%,100%{transform:scaleY(.2)}50%{transform:scaleY(1.0)}}
        @keyframes b5{0%,100%{transform:scaleY(.9)}50%{transform:scaleY(.4)}}
      `}</style>
    )}
    {([
      { x:1,  h:8,  an:"b1", dur:".65s" },
      { x:5,  h:14, an:"b2", dur:".85s" },
      { x:9,  h:18, an:"b3", dur:".55s" },
      { x:13, h:12, an:"b4", dur:".75s" },
      { x:17, h:6,  an:"b5", dur:".70s" },
    ] as const).map(({ x, h, an, dur }) => (
      <rect
        key={x} x={x} y={(22 - h) / 2} width="3" height={h} rx="1.5"
        fill="currentColor"
        opacity={active ? 1 : 0.25}
        style={active ? {
          transformOrigin: `${x + 1.5}px 11px`,
          animation: `${an} ${dur} ease-in-out infinite`,
        } : undefined}
      />
    ))}
    {!active && (
      <line x1="2" y1="2" x2="20" y2="20"
        stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" opacity="0.55"/>
    )}
  </svg>
);

export default function AudioController() {
  const { playing, toggle } = useBackgroundMusic();

  const handleClick = () => {
    bootAudio();
    toggle();
  };

  return (
    <button
      onClick={handleClick}
      data-hover
      title={playing ? "Tắt nhạc nền" : "Bật nhạc nền"}
      style={{
        position: "fixed", bottom: "2rem", right: "2rem", zIndex: 1000,
        width: 52, height: 52, borderRadius: "50%",
        background: playing ? "rgba(57,255,20,0.1)" : "rgba(10,10,10,0.85)",
        border: `1.5px solid ${playing ? "rgba(57,255,20,0.55)" : "rgba(255,255,255,0.09)"}`,
        backdropFilter: "blur(16px)",
        color: playing ? "var(--neon)" : "#444",
        display: "flex", alignItems: "center", justifyContent: "center",
        cursor: "none",
        transition: "all .3s cubic-bezier(.16,1,.3,1)",
        boxShadow: playing ? "0 0 28px rgba(57,255,20,0.28)" : "0 4px 20px rgba(0,0,0,0.5)",
      }}
      onMouseEnter={e => { (e.currentTarget as HTMLElement).style.transform = "scale(1.13)"; }}
      onMouseLeave={e => { (e.currentTarget as HTMLElement).style.transform = "scale(1)"; }}
    >
      <Bars active={playing} />
    </button>
  );
}
