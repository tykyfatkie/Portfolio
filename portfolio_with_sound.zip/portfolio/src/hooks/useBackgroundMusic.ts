import { useRef, useState, useCallback } from "react";

export function useBackgroundMusic() {
  const audioRef = useRef<HTMLAudioElement | null>(null);
  const frameRef = useRef(0);
  const [playing, setPlaying] = useState(false);

  const toggle = useCallback(() => {
    if (!audioRef.current) {
      audioRef.current = new Audio("/theme.mp3");
      audioRef.current.loop = true;
    }

    const audio = audioRef.current;
    cancelAnimationFrame(frameRef.current);

    if (audio.paused) {
      audio.volume = 0.3; // set thẳng, không fade
      audio.play()
        .then(() => {
          setPlaying(true);
          console.log("[music] ✓ playing, volume:", audio.volume, "duration:", audio.duration);
        })
        .catch(err => console.error("[music] ✗ failed:", err));
    } else {
      const ramp = () => {
        audio.volume = Math.max(audio.volume - 0.01, 0);
        if (audio.volume > 0) {
          frameRef.current = requestAnimationFrame(ramp);
        } else {
          audio.pause();
          setPlaying(false);
        }
      };
      frameRef.current = requestAnimationFrame(ramp);
    }
  }, []);

  return { playing, toggle };
}
